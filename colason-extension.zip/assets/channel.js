import{aH as o,aI as n}from"./main.js";const t=(a,r)=>o.lang.round(n.parse(a)[r]);export{t as c};
