import{c as r}from"./graph.js";var e=4;function a(o){return r(o,e)}export{a as c};
